* MSI plugin for Total Commander *

What is a MSI ?
---------------
See Wikipedia: https://en.wikipedia.org/wiki/Windows_Installer

How to instal this plugin
-------------------------
1. Locate the wcx_msi.zip file in Total Commander
2. Double-click on it with the mouse (or press Ctrl+PageDown)
3. Total Commander will tell you that the archive contains a MSI packer plugin
   and asks whether you want to install it. Click on "Yes".
4.

 (or double-cliOpen the ZIP file in Total Commander. It will ask to install, say "Yes".
Alternatively, you can install it by hand:

1. Copy the plugin file (msi.wcx) into the plugin subdirectory of Total Commander
   directory (Totalcmd\plugins\wcx\msi)
2. Start Total Commander and go to "Configuration\Options", page "Packer"
   and click the "Configre packer extension DLLs" at the bottom of the dialog box.
3. Enter "msi" into the extension and click the "New type" button. Locate the
   msi.wcx and press "Open"
4. Press "OK" to finish plugin installation


How to configure this plugin
----------------------------
1. In Total Commander, select a single file from your drive and press Alt+F5.
   The "Pack Files" dialog appears.
2. Press the "(o) ->" radio button and choose "msi" from the combo box.
3. Click the "Configure" button
4. Configure the MSI plugin and press "OK".

Files in the pack
-----------------
* msi.wcx      - 32-bit Total Commander plugin
* msi.wcx64    - 64-bit Total Commander plugin
* pluginst.inf - This file is recognized by Total Commander
* readme.txt   - This text file


 Authors
 -------
 The MSI plugin has been derived written by Ladik (http://www.zezula.net).

 Send any comments, suggestions and/or critics to zezula@volny.cz.

 Ladik
